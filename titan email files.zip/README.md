# 🏠 Titan Email Toolkit

Push HTML emails directly from Cursor into Mailchimp — no copy-pasting.

---

## Folder Structure

```
titanemailcampaigns/
├── .env                      ← Your API keys (never committed)
├── .env.example              ← Copy this to .env and fill in keys
├── .gitignore
├── push_to_mailchimp.py      ← Run this to push emails to Mailchimp
├── requirements.txt
├── emails/                   ← Finished email HTML files go here
│   └── yes-warranty-drip-1.html
├── templates/
│   └── base-template.html    ← Starting point for every new email
└── README.md
```

---

## First-Time Setup (Mac & PC)

### 1. Clone the repo
```bash
git clone https://github.com/joelckeith-web/titanemailcampaigns.git
cd titanemailcampaigns
```

### 2. Install Python dependencies
```bash
pip install -r requirements.txt
```
> On Mac you may need `pip3` instead of `pip`

### 3. Set up credentials
```bash
cp .env.example .env
```
Open `.env` and fill in:
- `MAILCHIMP_API_KEY` — Mailchimp → Account → Extras → API Keys
- `MAILCHIMP_LIST_ID` — Mailchimp → Audience → Settings → Audience name and defaults
- `MAILCHIMP_DC` — Last part of your API key (e.g. `us21`)

---

## Daily Workflow

### 1. Build an email in Cursor
- Open `templates/base-template.html` as your starting point
- Ask Cursor/Claude to write the email content
- Save the finished file into `/emails/`

### 2. Push it to Mailchimp
```bash
python push_to_mailchimp.py
```

Menu options:
```
[1] Push email as a new Mailchimp Template
[2] Push email into an existing draft Campaign
[3] Create a new draft Campaign + push email content
[4] List existing Mailchimp Templates
[5] Exit
```

---

## Design Specs (DO NOT change these)

**Brian's Signature Photo:**
- URL: `https://mcusercontent.com/43c61802199ce417708b5a1e7/_thumbs/d2570871-2050-a740-bc0f-7c53250081b0.png`
- width: `80px` | height: `140px` (portrait — NOT square, changing skews the circle)
- `border-radius: 50%` | `padding-right: 5px` | `vertical-align: middle`
- Table structure only — NO flexbox (breaks in Outlook/Gmail)

**Brand Colors:**
- Navy header: `#1a2e4a`
- Red CTA / links: `#e8472a`
- Light blue text on navy: `#a8bbd4`
- Body text: `#333333`
- Footer bg: `#f9f9f9`

---

## Cursor Prompt Template

```
Using base-template.html, write a Titan email for [PURPOSE].
Brian's voice — conversational, short paragraphs, ends with "All right. I'm just saying,"
Subject: [SUBJECT LINE]
CTA button: [TEXT] → [URL]
Save as emails/[filename].html
```

---

## Naming Conventions

| Type | Example |
|------|---------|
| YES Warranty drip | `yes-warranty-drip-2.html` |
| Agent nurture | `agent-nurture-spring-2026.html` |
| Seasonal | `spring-market-2026.html` |
| Re-engagement | `reengagement-90day.html` |

---

## Sync Between Machines

Pull latest:
```bash
git pull origin main
```

Push new email:
```bash
git add emails/your-new-email.html
git commit -m "Add: email name"
git push origin main
```

---

## Troubleshooting

**`ModuleNotFoundError`** → `pip install -r requirements.txt`

**`401 Unauthorized`** → Check API key in `.env`, no extra spaces

**`404 on campaign push`** → Campaign must be in **Draft** status; verify ID from Mailchimp URL
