#!/usr/bin/env python3
"""
Titan Email Toolkit — push_to_mailchimp.py
Pushes HTML email files to Mailchimp as templates or campaign content.
"""

import os
import sys
import json
import requests
from pathlib import Path
from dotenv import load_dotenv

# ── Load env ──────────────────────────────────────────────────────────────────
load_dotenv()

API_KEY  = os.getenv("MAILCHIMP_API_KEY")
LIST_ID  = os.getenv("MAILCHIMP_LIST_ID")
DC       = os.getenv("MAILCHIMP_DC", "us21")
BASE_URL = f"https://{DC}.api.mailchimp.com/3.0"
AUTH     = ("anystring", API_KEY)

# ── Helpers ───────────────────────────────────────────────────────────────────

def check_env():
    if not API_KEY or not LIST_ID:
        print("\n❌  Missing credentials. Copy .env.example → .env and fill in your keys.\n")
        sys.exit(1)

def list_emails():
    email_dir = Path("emails")
    files = sorted(email_dir.glob("*.html"))
    if not files:
        print("\n⚠️  No HTML files found in /emails folder.\n")
        sys.exit(1)
    return files

def pick_file(files):
    print("\n📧  Available emails:\n")
    for i, f in enumerate(files, 1):
        print(f"  [{i}] {f.name}")
    print()
    choice = input("Enter number to select email: ").strip()
    try:
        return files[int(choice) - 1]
    except (ValueError, IndexError):
        print("❌  Invalid selection.")
        sys.exit(1)

def read_html(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        return f.read()

# ── Actions ───────────────────────────────────────────────────────────────────

def push_as_template(html, name):
    """Save as a reusable template in Mailchimp."""
    url  = f"{BASE_URL}/templates"
    data = {"name": name, "html": html}
    r    = requests.post(url, auth=AUTH, json=data)
    if r.status_code == 200:
        tid = r.json().get("id")
        print(f"\n✅  Template created! ID: {tid}")
        print(f"    View in Mailchimp: https://{DC}.admin.mailchimp.com/templates/\n")
    else:
        print(f"\n❌  Error {r.status_code}: {r.json().get('detail')}\n")

def push_to_campaign(html):
    """Push HTML into an existing draft campaign."""
    print("\nEnter your Mailchimp Campaign ID (found in campaign URL):")
    campaign_id = input("Campaign ID: ").strip()
    url  = f"{BASE_URL}/campaigns/{campaign_id}/content"
    data = {"html": html}
    r    = requests.put(url, auth=AUTH, json=data)
    if r.status_code == 200:
        print(f"\n✅  Campaign content updated!")
        print(f"    View in Mailchimp: https://{DC}.admin.mailchimp.com/campaigns/\n")
    else:
        print(f"\n❌  Error {r.status_code}: {r.json().get('detail')}\n")

def create_and_push_campaign(html, name):
    """Create a new draft campaign and push HTML content into it."""
    print("\n📋  Let's set up the campaign:\n")
    subject    = input("Subject line: ").strip()
    from_name  = input("From name (default: Brian Dodds): ").strip() or "Brian Dodds"
    reply_to   = input("Reply-to email (default: info@titaninspectionservices.com): ").strip() or "info@titaninspectionservices.com"

    # Create campaign
    url  = f"{BASE_URL}/campaigns"
    data = {
        "type": "regular",
        "recipients": {"list_id": LIST_ID},
        "settings": {
            "subject_line": subject,
            "from_name":    from_name,
            "reply_to":     reply_to,
            "title":        name,
        }
    }
    r = requests.post(url, auth=AUTH, json=data)
    if r.status_code != 200:
        print(f"\n❌  Couldn't create campaign: {r.json().get('detail')}\n")
        return

    campaign_id = r.json().get("id")
    print(f"\n✅  Campaign draft created. ID: {campaign_id}")

    # Push content
    content_url  = f"{BASE_URL}/campaigns/{campaign_id}/content"
    content_data = {"html": html}
    r2 = requests.put(content_url, auth=AUTH, json=content_data)
    if r2.status_code == 200:
        print(f"✅  HTML content pushed!")
        print(f"    View in Mailchimp: https://{DC}.admin.mailchimp.com/campaigns/\n")
    else:
        print(f"\n❌  Content push failed: {r2.json().get('detail')}\n")

def list_existing_templates():
    """Preview what templates already exist in Mailchimp."""
    url = f"{BASE_URL}/templates?count=20&type=user"
    r   = requests.get(url, auth=AUTH)
    if r.status_code == 200:
        templates = r.json().get("templates", [])
        if not templates:
            print("\n⚠️  No custom templates found in Mailchimp.\n")
            return
        print(f"\n📁  Existing Mailchimp templates ({len(templates)}):\n")
        for t in templates:
            print(f"  ID: {t['id']}  |  {t['name']}")
        print()
    else:
        print(f"\n❌  Error: {r.json().get('detail')}\n")

# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    check_env()

    print("\n" + "="*50)
    print("  🏠  TITAN EMAIL TOOLKIT")
    print("="*50)

    print("""
What would you like to do?

  [1] Push email as a new Mailchimp Template
  [2] Push email into an existing draft Campaign
  [3] Create a new draft Campaign + push email content
  [4] List existing Mailchimp Templates
  [5] Exit
""")

    action = input("Choose an option: ").strip()

    if action == "4":
        list_existing_templates()
        return

    if action == "5":
        print("\nBye!\n")
        return

    if action not in ("1", "2", "3"):
        print("❌  Invalid option.")
        sys.exit(1)

    files    = list_emails()
    filepath = pick_file(files)
    html     = read_html(filepath)
    name     = filepath.stem.replace("-", " ").replace("_", " ").title()

    print(f"\n📄  Selected: {filepath.name}  ({len(html):,} chars)\n")

    if action == "1":
        push_as_template(html, name)
    elif action == "2":
        push_to_campaign(html)
    elif action == "3":
        create_and_push_campaign(html, name)


if __name__ == "__main__":
    main()
