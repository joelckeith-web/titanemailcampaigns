# 🏠 Titan Email Toolkit

Push HTML emails directly from Cursor into Mailchimp — no copy-pasting.

---

## Folder Structure

```
titan-email-toolkit/
├── .env                      ← Your API keys (never committed)
├── .env.example              ← Template — copy this to .env
├── .gitignore
├── push_to_mailchimp.py      ← Run this to push emails
├── requirements.txt
├── emails/                   ← All finished email HTML files go here
│   └── yes-warranty-drip-1.html
├── templates/
│   └── base-template.html    ← Starting point for new emails
└── README.md
```

---

## First-Time Setup (Mac & PC)

### 1. Clone the repo
```bash
git clone https://github.com/joelckeith-web/titanemailcampaigns.git
cd titan-email-toolkit
```

### 2. Install Python dependencies
```bash
pip install -r requirements.txt
```

> On Mac you may need `pip3` instead of `pip`

### 3. Set up your credentials
```bash
cp .env.example .env
```
Open `.env` and fill in:
- `MAILCHIMP_API_KEY` — Mailchimp → Account → Extras → API Keys
- `MAILCHIMP_LIST_ID` — Mailchimp → Audience → Settings → Audience name and defaults
- `MAILCHIMP_DC` — Last part of your API key (e.g. `us21`)

---

## Daily Workflow

### 1. Build an email in Cursor
- Open `templates/base-template.html` as your starting point
- Ask Claude/Cursor to write the email content
- Save the finished file into the `/emails/` folder

### 2. Push it to Mailchimp
```bash
python push_to_mailchimp.py
```

You'll see a menu:
```
[1] Push email as a new Mailchimp Template
[2] Push email into an existing draft Campaign
[3] Create a new draft Campaign + push email content
[4] List existing Mailchimp Templates
[5] Exit
```

Pick your option, select the file, done.

---

## Cursor Prompt Tips

When building a new email in Cursor, use prompts like:

```
Using base-template.html, write a Titan email for [purpose].
Brian's voice — conversational, short paragraphs, "All right. I'm just saying."
Subject: [your subject line idea]
CTA: [button text + URL]
Save as emails/[filename].html
```

---

## Naming Conventions

| Type | Example filename |
|------|-----------------|
| YES Warranty drip | `yes-warranty-drip-1.html` |
| Agent nurture | `agent-nurture-spring-2025.html` |
| Seasonal campaign | `spring-market-2025.html` |
| Re-engagement | `reengagement-90day.html` |
| GMB follow-up | `gbp-followup-seattle.html` |

---

## Pulling Latest Changes (on second machine)
```bash
git pull origin main
```

---

## Saving New Emails to GitHub
```bash
git add emails/your-new-email.html
git commit -m "Add: yes-warranty-drip-2"
git push origin main
```

---

## Troubleshooting

**`ModuleNotFoundError: No module named 'dotenv'`**
```bash
pip install python-dotenv
```

**`401 Unauthorized`**
- Double-check your API key in `.env`
- Make sure there are no extra spaces

**`404 Not Found` on campaign push**
- Verify the Campaign ID is correct (find it in the Mailchimp campaign URL)
- Campaign must be in **Draft** status

---

## Questions?
Contact: info@titaninspectionservices.com
